# dog
This is a peusdo-fork of http://dogs.are.the.most.moe/, which was made by [\@i_am_agm](http://twitter.com/i_am_agm). The only difference is that the keyboard also increases the timer, so it's much easier to get the dog spinning at absurd speeds.

This was originally located in my schobbish.github.io repo, but I moved it out because I was moving to a custom domain and I wanted this to be on a custom subdomain. 
